//
//  Analgetics+CoreDataClass.swift
//  core-data
//
//  Created by Анна Желтова on 2/20/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Analgetics)
public class Analgetics: NSManagedObject {

}
