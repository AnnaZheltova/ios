//
//  AnalgeticTableViewController.swift
//  core-data
//
//  Created by Анна Желтова on 2/20/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit
import CoreData

class AntisepticsTableViewController: UITableViewController {
    var medications = [AllMedicine]()
    
    
   
    
    override func viewWillAppear(_ animated: Bool) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "AllMedicine" )
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        do{
            let results = try context.fetch(request)
            if results.count>0{
                for result in results as! [NSManagedObject]
                {
                     if medications.contains(result as! AllMedicine)==false{
                        let nameResult = result.value(forKey: "type")
                        if "Антисептики" == nameResult as! String {
                            medications.append(result as! AllMedicine)
                        }
                    }
                }
            }
        }catch{
            
        }
        tableView.reloadData()
    }
 
    override func viewDidLoad() {

        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return medications.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: AntisepticsTableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! AntisepticsTableViewCell
        let analgetic = medications[indexPath.row]
        cell.nameOf?.text = analgetic.name
        cell.amountOf?.text = String(analgetic.amount)
        cell.priceOf?.text = String(analgetic.price)
        cell.stepper.value = Double(analgetic.amount)
        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    


    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case .delete:
            // remove the deleted item from the model
          let appDelegate = UIApplication.shared.delegate as! AppDelegate
           let context = appDelegate.persistentContainer.viewContext
            context.delete(medications[indexPath.row] as NSManagedObject)
            medications.remove(at:indexPath.row)
            do{
                try context.save()
                print("saved!")
                
            }catch{
                print(error.localizedDescription)
            }
            
            //tableView.reloadData()
            // remove the deleted item from the `UITableView`
            self.tableView.deleteRows(at: [indexPath], with: .fade)
        default:
            return
            
        }
    }


    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
