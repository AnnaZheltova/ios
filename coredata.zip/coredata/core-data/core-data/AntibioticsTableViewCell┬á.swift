//
//  MedicationTableViewCell.swift
//  core-data
//
//  Created by Анна Желтова on 2/23/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit
import CoreData

class AntibioticsTableViewCell: UITableViewCell {
     var medications = [AllMedicine]()
    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var priceOf: UILabel!
    @IBOutlet weak var nameOf: UILabel!
    @IBOutlet weak var amountOf: UILabel!
    
    func SaveFarmacy(name: String,amount: Int32, price: Double){
       let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "AllMedicine" )
        do{
            let results = try context.fetch(request)
            if results.count>0{
                for result in results as! [NSManagedObject]
                {
                    let nameResult = result.value(forKey: "name")
                    if name == nameResult as! String {
                        result.setValue(amount, forKey: "amount")
                        do{
                            try context.save()
                        }catch{
                            
                        }
                    }
                }
            }
        }catch{
            
        }


    }
    
    @IBAction func stepperAction(_ sender: UIStepper) {
        amountOf.text = "\(Int(stepper.value))"
        SaveFarmacy(name: (nameOf.text)!, amount: (Int32((amountOf.text)!)!), price: (Double((priceOf.text)!)!))
    }
    



}
