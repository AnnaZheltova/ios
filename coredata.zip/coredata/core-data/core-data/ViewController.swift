//
//  ViewController.swift
//  core-data
//
//  Created by Анна Желтова on 2/13/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
   
   
    
    
   
   
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    


}

