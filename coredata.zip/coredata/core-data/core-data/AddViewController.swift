//
//  AddViewController.swift
//  core-data
//
//  Created by Анна Желтова on 2/28/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    

    @IBOutlet weak var NameOfMedicine: UITextField!
    @IBOutlet weak var AmountOfMedicine: UITextField!
    @IBOutlet weak var PriceOfMedicine: UITextField!
    
    @IBOutlet weak var ChooseType: UIPickerView!
    @IBOutlet weak var TypeOfMedicine: UILabel!
    
    
    var types=["Анальгетики", "Антибіотики", "Антигістамінні", "Антисептики", "Гіпотензивні", "Серцеві"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TypeOfMedicine.text = types[0]
        ChooseType.delegate=self
        ChooseType.dataSource=self
        NameOfMedicine.becomeFirstResponder();

    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return types.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return types[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        TypeOfMedicine.text = types[row]
    }
    
    @IBAction func AddMedicine(_ sender: UIButton) {
        if (NameOfMedicine.text?.isEmpty)==false && (TypeOfMedicine.text?.isEmpty)==false && (AmountOfMedicine.text?.isEmpty)==false && (PriceOfMedicine.text?.isEmpty)==false {
            SaveFarmacy(name: (NameOfMedicine.text)!, type: (TypeOfMedicine.text)!,amount: (Int32((AmountOfMedicine.text)!)!), price: (Double((PriceOfMedicine.text)!)!))
            self.navigationController?.popViewController(animated: true)
        }else{
            let alertController = UIAlertController(title: "Зверніть увагу!", message: "Заповніть всі поля", preferredStyle: .alert)
            
            let action1 = UIAlertAction(title: "Ok", style: .default)
            alertController.addAction(action1)
            self.present(alertController, animated: true, completion: nil)
           
            
        }
    }
    
    func SaveFarmacy(name: String, type: String, amount: Int32, price: Double){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
     
        let entity =  NSEntityDescription.entity(forEntityName: "AllMedicine", in: context)
        let AllMedicineObject = NSManagedObject(entity: entity!, insertInto: context) as! AllMedicine
        AllMedicineObject.name = name
        AllMedicineObject.type = type
        AllMedicineObject.amount = amount
        AllMedicineObject.price = price
        do{
            try context.save()
            print("saved!")
            
        }catch{
            print(error.localizedDescription)
        }
       
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
