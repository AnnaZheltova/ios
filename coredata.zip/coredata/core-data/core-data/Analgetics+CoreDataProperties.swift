//
//  Analgetics+CoreDataProperties.swift
//  core-data
//
//  Created by Анна Желтова on 2/20/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//
//

import Foundation
import CoreData


extension Analgetics {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Analgetics> {
        return NSFetchRequest<Analgetics>(entityName: "Analgetics")
    }

    @NSManaged public var amount: Int32
    @NSManaged public var name: String?
    @NSManaged public var price: Double

}
